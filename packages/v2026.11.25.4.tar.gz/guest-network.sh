#!/bin/sh
# Guest Wi-Fi (second 5GHz AP) on its own direct network 10.10.30.0/24; no new daemon.
# The network, DHCP pool, firewall zone and OpenClash exclusion are created at first boot
# (factory); the Wi-Fi itself stays off and has no name or password until set in the panel.
#   factory  first-boot UCI setup (no commit; the caller commits)
#   runtime  put the OpenClash bypass for br-guest first (called by OpenClash's firewall hook)
#   dns      hand guests the WAN's own DNS servers (called on WAN ifup/ifupdate)
set -eu
GUEST_IP=10.10.30.1
GUEST_SUBNET=10.10.30.0/24
FALLBACK_DNS=223.5.5.5,119.29.29.29

runtime() {
  for chain in openclash openclash_mangle openclash_dns_redirect dstnat; do
    nft list chain inet fw4 "$chain" >/dev/null 2>&1 || continue
    nft -a list chain inet fw4 "$chain" | sed -n '/comment "RouteLite guest bypass"/s/.*# handle //p' | while read -r handle; do nft delete rule inet fw4 "$chain" handle "$handle"; done
    nft insert rule inet fw4 "$chain" iifname br-guest counter return comment '"RouteLite guest bypass"'
  done
}

dns_update() {
  uci -q get dhcp.routelite_guest >/dev/null || return 0
  # Only real upstream resolvers; never the router itself or OpenClash's fake-IP range.
  servers=$(ubus call network.interface.wan status 2>/dev/null | jsonfilter -e '@["dns-server"][*]' | awk '/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && $0 !~ /^127\./ && $0 !~ /^198\.1[89]\./ && $0 !~ /^10\.10\.(10|30)\./ {if(n++)printf ",";printf "%s",$0}')
  [ -n "$servers" ] || servers=$FALLBACK_DNS
  desired="6,$servers"
  [ "$(uci -q get dhcp.routelite_guest.dhcp_option || true)" = "$desired" ] && return 0
  uci -q delete dhcp.routelite_guest.dhcp_option || true
  uci add_list "dhcp.routelite_guest.dhcp_option=$desired"
  uci commit dhcp
  [ "${DNS_NO_RELOAD:-0}" = 1 ] || /etc/init.d/dnsmasq reload
}

factory() {
  uci -q batch <<UCI
set network.routelite_guest_dev=device
set network.routelite_guest_dev.name='br-guest'
set network.routelite_guest_dev.type='bridge'
set network.routelite_guest_dev.bridge_empty='1'
set network.routelite_guest=interface
set network.routelite_guest.device='br-guest'
set network.routelite_guest.proto='static'
set network.routelite_guest.ipaddr='$GUEST_IP'
set network.routelite_guest.netmask='255.255.255.0'
set network.routelite_guest.delegate='0'
set dhcp.routelite_guest=dhcp
set dhcp.routelite_guest.interface='routelite_guest'
set dhcp.routelite_guest.start='100'
set dhcp.routelite_guest.limit='150'
set dhcp.routelite_guest.leasetime='4h'
set dhcp.routelite_guest.ra='disabled'
set dhcp.routelite_guest.dhcpv6='disabled'
set dhcp.routelite_guest.ndp='disabled'
delete dhcp.routelite_guest.dhcp_option
add_list dhcp.routelite_guest.dhcp_option='6,$FALLBACK_DNS'
set firewall.routelite_guest=zone
set firewall.routelite_guest.name='guest'
set firewall.routelite_guest.network='routelite_guest'
set firewall.routelite_guest.input='REJECT'
set firewall.routelite_guest.output='ACCEPT'
set firewall.routelite_guest.forward='REJECT'
set firewall.routelite_guest_dhcp=rule
set firewall.routelite_guest_dhcp.name='Guest DHCP only'
set firewall.routelite_guest_dhcp.src='guest'
set firewall.routelite_guest_dhcp.proto='udp'
set firewall.routelite_guest_dhcp.dest_port='67'
set firewall.routelite_guest_dhcp.family='ipv4'
set firewall.routelite_guest_dhcp.target='ACCEPT'
set firewall.routelite_guest_dns=rule
set firewall.routelite_guest_dns.name='Guest upstream DNS'
set firewall.routelite_guest_dns.src='guest'
set firewall.routelite_guest_dns.dest='wan'
set firewall.routelite_guest_dns.proto='tcp udp'
set firewall.routelite_guest_dns.dest_port='53'
set firewall.routelite_guest_dns.family='ipv4'
set firewall.routelite_guest_dns.target='ACCEPT'
set firewall.routelite_guest_private=rule
set firewall.routelite_guest_private.name='Guest block private networks'
set firewall.routelite_guest_private.src='guest'
set firewall.routelite_guest_private.dest='*'
set firewall.routelite_guest_private.proto='all'
set firewall.routelite_guest_private.family='ipv4'
set firewall.routelite_guest_private.target='REJECT'
set firewall.routelite_guest_private.dest_ip='10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 169.254.0.0/16 100.64.0.0/10 198.18.0.0/15'
set firewall.routelite_guest_wan=forwarding
set firewall.routelite_guest_wan.src='guest'
set firewall.routelite_guest_wan.dest='wan'
set firewall.routelite_lan_guest=rule
set firewall.routelite_lan_guest.name='Main network cannot access guests'
set firewall.routelite_lan_guest.src='lan'
set firewall.routelite_lan_guest.dest='guest'
set firewall.routelite_lan_guest.proto='all'
set firewall.routelite_lan_guest.target='REJECT'
reorder firewall.routelite_guest_dns=0
UCI
}

case "${1:-}" in
  factory) factory;;
  runtime) runtime;;
  dns) dns_update;;
  *) echo "usage: $0 factory|runtime|dns" >&2; exit 1;;
esac
