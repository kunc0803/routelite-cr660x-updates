/* 节点解析 + OpenClash(mihomo) 配置生成。浏览器和 Node 共用，无依赖。 */
(function (root) {
  'use strict';

  var SWITCH_TOLERANCE_MS = 100;
  var HEALTH_URL = 'http://www.gstatic.com/generate_204';
  var RESERVED = ['PROXY', 'AUTO', 'DIRECT', 'REJECT', 'GLOBAL', 'PANEL-BLOCKED-EXIT'];
  var CHECK_PREFIX = 'PANEL-CHECK@';
  var SS_CIPHERS = new Set([
    'aes-128-ctr', 'aes-192-ctr', 'aes-256-ctr', 'aes-128-cfb', 'aes-192-cfb', 'aes-256-cfb',
    'aes-128-gcm', 'aes-192-gcm', 'aes-256-gcm', 'aes-128-ccm', 'aes-192-ccm', 'aes-256-ccm',
    'aes-128-gcm-siv', 'aes-256-gcm-siv', 'chacha20-ietf', 'chacha20', 'xchacha20',
    'chacha20-ietf-poly1305', 'xchacha20-ietf-poly1305', 'chacha8-ietf-poly1305', 'xchacha8-ietf-poly1305',
    '2022-blake3-aes-128-gcm', '2022-blake3-aes-256-gcm', '2022-blake3-chacha20-poly1305',
    'lea-128-gcm', 'lea-192-gcm', 'lea-256-gcm', 'rabbit128-poly1305',
    'aegis-128l', 'aegis-256', 'aez-384', 'deoxys-ii-256-128', 'rc4-md5', 'none'
  ]);

  function stripBrackets(h) { return h.replace(/^\[|\]$/g, ''); }
  function isIPv4(s) { return /^(\d{1,3}\.){3}\d{1,3}$/.test(s); }
  function isIPv6(s) { return s.indexOf(':') >= 0 && /^[0-9a-f:.]+$/i.test(s); }

  /* ---------- 名字：节点/出口/订阅里的名字不能重复，也不能用保留名 ---------- */
  function nameTaken(state, name) {
    if (RESERVED.indexOf(name) >= 0 || name.indexOf(CHECK_PREFIX) === 0) return true;
    return (state.nodes || []).concat(state.exits || []).some(function (x) { return x.name === name; });
  }
  function uniqueName(state, name) {
    if (name.indexOf(CHECK_PREFIX) === 0) name = '节点 ' + name;
    if (!nameTaken(state, name)) return name;
    for (var i = 2; ; i++) if (!nameTaken(state, name + ' ' + i)) return name + ' ' + i;
  }

  /* ---------- vless 单节点 ---------- */
  function parseVless(link) {
    link = String(link || '').trim();
    if (!/^vless:\/\//i.test(link)) throw new Error('不是 vless:// 开头的链接');
    var u;
    try { u = new URL(link); }
    catch (e) { throw new Error('链接格式不对'); }
    var q = function (k) { return u.searchParams.get(k) || ''; };
    var server = parseServer(u.hostname);
    var port = parsePort(u.port);
    var uuid = decodeURIComponent(u.username);
    if (!validUuid(uuid)) throw new Error('UUID 格式不对');
    var enc = q('encryption');
    if (enc && enc !== 'none') throw new Error('暂不支持 encryption=' + enc);

    var net = q('type') || 'tcp';
    if (net === 'raw') net = 'tcp';
    if (['tcp', 'ws', 'grpc', 'h2', 'http', 'httpupgrade'].indexOf(net) < 0) throw new Error('暂不支持传输方式 ' + net);

    var name = '';
    try { name = decodeURIComponent((u.hash || '').replace(/^#/, '')); } catch (e) { name = (u.hash || '').replace(/^#/, ''); }
    name = name.trim().slice(0, 40) || (server + ':' + port);

    var sec = q('security');
    var p = { name: name, type: 'vless', server: server, port: port, uuid: uuid, udp: true };
    if (q('flow')) p.flow = q('flow');

    if (sec === 'tls' || sec === 'reality') {
      p.tls = true;
      var sni = q('sni') || q('peer');
      if (sni) p.servername = sni;
      var fp = q('fp');
      if (fp) p['client-fingerprint'] = fp;
      if (q('alpn')) p.alpn = q('alpn').split(',');
      if (q('allowInsecure') === '1' || q('insecure') === '1') p['skip-cert-verify'] = true;
    } else if (sec && sec !== 'none') {
      throw new Error('暂不支持 security=' + sec);
    }
    if (sec === 'reality') {
      if (!q('pbk')) throw new Error('reality 缺少 pbk（公钥）');
      if (!p['client-fingerprint']) p['client-fingerprint'] = 'chrome';
      p['reality-opts'] = { 'public-key': q('pbk'), 'short-id': q('sid') };
    }

    applyTransport(p, net, q('path'), q('host'), q('serviceName'));
    return p;
  }

  function parseNodeLink(link) {
    link = String(link || '').trim();
    var protocol = link.split('://', 1)[0].toLowerCase();
    if (protocol === 'vless') return parseVless(link);
    if (protocol === 'ss') return parseShadowsocks(link);
    if (protocol === 'trojan') return parseTrojan(link);
    if (protocol === 'vmess') return parseVmess(link);
    if (['hysteria2', 'hy2', 'hysteria', 'tuic', 'anytls', 'socks', 'socks5', 'socks5h', 'http-proxy', 'https-proxy'].includes(protocol)) return parseExtendedLink(link, protocol);
    if (protocol === 'ssr') return parseSSR(link);
    if (protocol === 'http' || protocol === 'https') throw new Error('请使用「导入链接」添加订阅');
    throw new Error('不支持此链接格式；请查看输入框中的协议列表');
  }

  function shareUrl(link) {
    try {
      return new URL(link);
    } catch (error) {
      throw new Error('链接格式不对');
    }
  }

  function shareParam(url) {
    return function (key) { return url.searchParams.get(key) || ''; };
  }

  function decodeBase64(value) {
    try {
      var raw = atob(value.replace(/-/g, '+').replace(/_/g, '/'));
      return new TextDecoder('utf-8', { fatal: true }).decode(Uint8Array.from(raw, function (ch) { return ch.charCodeAt(0); }));
    } catch (error) {
      throw new Error('节点链接的 Base64 内容无效');
    }
  }

  function shareName(name, server, port) {
    return String(name || '').trim().slice(0, 40) || server + ':' + port;
  }

  function urlName(url) {
    return decodeURIComponent(url.hash.slice(1));
  }

  function parseServer(server) {
    var raw = decodeURIComponent(String(server || '')).trim();
    if (isIPv6(raw)) raw = '[' + raw + ']';
    if (!raw || /[\s\/\\?#@]/.test(raw)) throw new Error('服务器地址无效');
    if (raw.indexOf(':') >= 0 && raw[0] !== '[') throw new Error('服务器地址不应包含端口');
    try {
      var url = new URL('http://' + raw);
      if (url.port || !url.hostname || (raw[0] === '[' && !raw.endsWith(']'))) throw new Error();
      return stripBrackets(url.hostname);
    } catch (error) {
      throw new Error('服务器地址无效');
    }
  }

  function parsePort(port) {
    if (!/^\d+$/.test(String(port)) || +port < 1 || +port > 65535) throw new Error('端口应为 1–65535');
    return Number(port);
  }

  function validUuid(uuid) {
    return typeof uuid === 'string' && /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(uuid);
  }

  function listOf(value) {
    return String(value || '').split(',').map(function (item) { return item.trim(); }).filter(Boolean);
  }

  function applyTransport(p, network, path, host, service) {
    p.network = network;
    if (network === 'ws' || network === 'httpupgrade') {
      p['ws-opts'] = { path: path || '/' };
      if (host) p['ws-opts'].headers = { Host: host };
      if (network === 'httpupgrade') {
        p.network = 'ws';
        p['ws-opts']['v2ray-http-upgrade'] = true;
      }
    } else if (network === 'grpc') {
      p['grpc-opts'] = { 'grpc-service-name': service || path || '' };
    } else if (network === 'h2') {
      p['h2-opts'] = { path: path || '/' };
      if (host) p['h2-opts'].host = listOf(host);
    } else if (network === 'http') {
      p['http-opts'] = { method: 'GET', path: [path || '/'] };
      if (host) p['http-opts'].headers = { Host: listOf(host) };
    }
  }

  function readTls(p, get, sniKey, security) {
    if (security !== 'tls' && security !== 'reality') throw new Error('暂不支持这种传输层安全设置');
    p.tls = true;
    var sni = get('sni') || get('peer');
    if (sni) p[sniKey] = sni;
    if (get('fp')) p['client-fingerprint'] = get('fp');
    var alpn = listOf(get('alpn'));
    if (alpn.length) p.alpn = alpn;
    if (/^(1|true)$/i.test(get('allowInsecure') || get('insecure'))) p['skip-cert-verify'] = true;
    if (get('vcn')) p['name-cert-verify'] = get('vcn');
    if (get('pcs')) p.fingerprint = get('pcs');
    if (security === 'reality') {
      if (!get('pbk')) throw new Error('REALITY 缺少公钥');
      p['client-fingerprint'] = p['client-fingerprint'] || 'chrome';
      p['reality-opts'] = { 'public-key': get('pbk'), 'short-id': get('sid') };
    }
  }

  function parseShadowsocks(link) {
    var parts = link.slice(5).match(/^([^?#]*)(\?[^#]*)?(#.*)?$/);
    if (!parts || !parts[1]) throw new Error('Shadowsocks 链接格式不对');
    var body = parts[1];
    var legacy = body.indexOf('@') < 0;
    if (legacy) body = decodeBase64(body);
    var at = body.lastIndexOf('@');
    if (at <= 0) throw new Error('Shadowsocks 链接缺少认证信息或服务器');
    var credentials = body.slice(0, at);
    if (!legacy) {
      var decoded = decodeURIComponent(credentials);
      credentials = credentials.indexOf(':') >= 0 ? decoded : decodeBase64(decoded);
    }
    var sep = credentials.indexOf(':');
    if (sep <= 0) throw new Error('Shadowsocks 链接缺少加密方式');
    var url = shareUrl('ss://' + body.slice(at + 1) + (parts[2] || '') + (parts[3] || ''));
    if (url.pathname && url.pathname !== '/') throw new Error('Shadowsocks 服务器格式不正确');
    var server = parseServer(url.hostname), port = parsePort(url.port);
    var cipher = credentials.slice(0, sep).toLowerCase();
    if (!SS_CIPHERS.has(cipher)) {
      throw new Error('暂不支持这种 Shadowsocks 加密方式');
    }
    var password = credentials.slice(sep + 1);
    if (!password && cipher !== 'none') throw new Error('Shadowsocks 链接缺少密码');
    if (cipher.indexOf('2022-') === 0) {
      var expectedBytes = cipher === '2022-blake3-aes-128-gcm' ? 16 : 32;
      try {
        if (!password.split(':').every(function (key) { return atob(key).length === expectedBytes; })) throw new Error();
      } catch (error) {
        throw new Error('Shadowsocks 2022 密钥格式或长度不正确');
      }
    }
    var p = { name: shareName(urlName(url), server, port), type: 'ss', server: server, port: port,
      cipher: cipher, password: password, udp: true };
    var plugin = url.searchParams.get('plugin');
    if (plugin) applySSPlugin(p, plugin);
    return p;
  }

  function applySSPlugin(p, raw) {
    var pieces = raw.match(/(?:\\.|[^\\;])+/g) || [];
    var name = pieces.shift();
    var values = Object.create(null);
    pieces.forEach(function (piece) {
      var eq = piece.indexOf('=');
      var key = eq < 0 ? piece : piece.slice(0, eq);
      values[key] = eq < 0 ? true : piece.slice(eq + 1).replace(/\\([\\;=:])/g, '$1');
    });
    var keys = Object.keys(values);
    if (/^(obfs|obfs-local|simple-obfs)$/.test(name) && keys.every(function (key) { return ['obfs', 'obfs-host'].includes(key); })) {
      if (!/^(http|tls)$/.test(values.obfs)) throw new Error('Shadowsocks obfs 插件缺少 http 或 tls 模式');
      p.plugin = 'obfs';
      p['plugin-opts'] = { mode: values.obfs };
      if (typeof values['obfs-host'] === 'string') p['plugin-opts'].host = values['obfs-host'];
    } else if (name === 'v2ray-plugin' && keys.every(function (key) { return ['mode', 'host', 'path', 'tls', 'mux'].includes(key); })) {
      if ((values.mode && values.mode !== 'websocket') || ('mux' in values && !/^(0|1|true|false)$/i.test(values.mux))) {
        throw new Error('暂不支持这种 v2ray-plugin 模式或复用设置');
      }
      p.plugin = 'v2ray-plugin';
      p['plugin-opts'] = { mode: 'websocket' };
      ['host', 'path'].forEach(function (key) {
        if (typeof values[key] === 'string') p['plugin-opts'][key] = values[key];
      });
      if ('tls' in values) p['plugin-opts'].tls = /^(true|1)$/i.test(values.tls);
      if ('mux' in values) p['plugin-opts'].mux = /^(true|1)$/i.test(values.mux);
    } else {
      throw new Error('暂不支持这个 Shadowsocks 插件或它的参数');
    }
  }

  function parseTrojan(link) {
    var url = shareUrl(link), get = shareParam(url);
    var server = parseServer(url.hostname), port = parsePort(url.port || 443);
    var password = decodeURIComponent(url.username + (url.password ? ':' + url.password : ''));
    if (!password) throw new Error('Trojan 链接缺少密码');
    if (get('encryption') && get('encryption') !== 'none') throw new Error('暂不支持这种 Trojan 扩展加密');
    var network = get('type') || 'tcp';
    if (network === 'raw') network = 'tcp';
    if (!['tcp', 'ws', 'grpc'].includes(network)) throw new Error('暂不支持这种 Trojan 传输方式');
    if (network === 'grpc' && (get('authority') || (get('mode') && get('mode') !== 'gun'))) throw new Error('暂不支持这种 gRPC 设置');
    var p = { name: shareName(urlName(url), server, port), type: 'trojan', server: server, port: port, password: password, udp: true };
    readTls(p, get, 'sni', get('security') || 'tls');
    delete p.tls; // Trojan 内核出站本身使用 TLS。
    applyTransport(p, network, get('path'), get('host'), get('serviceName'));
    return p;
  }

  function parseVmess(link) {
    var json, url, get;
    if (link.slice(8).split(/[?#]/, 1)[0].indexOf('@') >= 0) {
      url = shareUrl(link);
      get = shareParam(url);
      json = {
        ps: urlName(url), add: url.hostname, port: url.port, id: decodeURIComponent(url.username),
        aid: get('alterId'), scy: get('encryption'), net: get('type'), type: get('headerType'),
        path: get('path'), host: get('host'), tls: get('security')
      };
    } else {
      try { json = JSON.parse(decodeBase64(link.slice(8))); }
      catch (error) { throw new Error('VMess 链接需要有效的 Base64 JSON 节点'); }
      if (!json || typeof json !== 'object' || Array.isArray(json)) throw new Error('VMess 配置格式无效');
      get = function (key) { return typeof json[key] === 'string' || typeof json[key] === 'number' ? String(json[key]) : ''; };
    }
    var server = parseServer(json.add), port = parsePort(json.port);
    if (!validUuid(json.id)) throw new Error('VMess UUID 格式不对');
    var alterId = json.aid === undefined || json.aid === '' ? 0 : json.aid;
    if (!/^\d+$/.test(String(alterId)) || +alterId > 65535) throw new Error('VMess alterId 无效');
    var cipher = String(json.scy || 'auto').toLowerCase();
    if (!['auto', 'none', 'zero', 'aes-128-gcm', 'chacha20-poly1305'].includes(cipher)) throw new Error('暂不支持这种 VMess 加密方式');
    var network = String(json.net || 'tcp').toLowerCase();
    if (network === 'raw') network = 'tcp';
    var header = String(json.type || '').toLowerCase();
    if (!['tcp', 'ws', 'grpc', 'h2', 'http', 'httpupgrade'].includes(network) ||
        (header && !['none', 'http'].includes(header) && !(network === 'grpc' && header === 'gun'))) {
      throw new Error('暂不支持这种 VMess 传输方式或伪装类型');
    }
    if (network === 'grpc' && (get('authority') || (get('mode') && get('mode') !== 'gun'))) throw new Error('暂不支持这种 gRPC 设置');
    if (header === 'http' && network === 'tcp') network = 'http';
    else if (network === 'http' && header !== 'http') network = 'h2';
    var p = { name: shareName(json.ps, server, port), type: 'vmess', server: server, port: port, uuid: json.id,
      alterId: Number(alterId), cipher: cipher, udp: true };
    var security = String(json.tls || '').toLowerCase();
    if (security && security !== 'none' && security !== 'false' && security !== '0') readTls(p, get, 'servername', security);
    applyTransport(p, network, json.path, json.host, get('serviceName'));
    return p;
  }

  // Share links are parsed only in the browser; no extra daemon or library.
  function checkShareParams(url, allowed) {
    url.searchParams.forEach(function (_, key) {
      if (!allowed.includes(key)) throw new Error('暂不支持链接参数：' + key + '，请使用兼容的 Clash 订阅');
    });
    if (url.pathname && url.pathname !== '/') throw new Error('节点链接不应包含路径');
  }
  function readShareTLS(p, get) {
    var sni = get('sni') || get('peer');
    if (sni) p.sni = sni;
    var insecure = get('insecure') || get('allowInsecure') || get('allow_insecure') || get('skip-cert-verify');
    if (insecure) {
      if (!/^(0|1|true|false)$/i.test(insecure)) throw new Error('证书校验参数无效');
      p['skip-cert-verify'] = /^(1|true)$/i.test(insecure);
    }
    if (get('alpn')) p.alpn = listOf(get('alpn'));
    if (get('fp')) p['client-fingerprint'] = get('fp');
    if (get('pinSHA256')) p.fingerprint = get('pinSHA256');
  }
  function parseExtendedLink(link, scheme) {
    var hopping = '';
    if (scheme === 'hy2' || scheme === 'hysteria2') {
      // WHATWG URL cannot parse a port range. Normalize only the authority port.
      link = link.replace(/^(hysteria2|hy2):\/\/([^/?#]+)(.*)$/i, function (_, proto, authority, rest) {
        var m = authority.match(/:([0-9]+(?:[-,][0-9]+)+)$/);
        if (!m) return _;
        hopping = m[1];
        hopping.split(',').forEach(function (part) {
          var ends = part.split('-');
          ends.forEach(parsePort);
          if (ends.length > 2 || (ends.length === 2 && +ends[0] > +ends[1])) throw new Error('跳跃端口范围无效');
        });
        return proto + '://' + authority.slice(0, -m[0].length) + ':' + hopping.split(/[-,]/)[0] + rest;
      });
    }
    var url = shareUrl(link), get = shareParam(url);
    var server = parseServer(url.hostname);
    var type = /^(hy2|hysteria2)$/.test(scheme) ? 'hysteria2' : /^socks/.test(scheme) ? 'socks5' : /-proxy$/.test(scheme) ? 'http' : scheme;
    var port = parsePort(url.port || (type === 'socks5' ? 1080 : scheme === 'http-proxy' ? 80 : 443));
    var p = { name: shareName(urlName(url), server, port), type: type, server: server, port: port };
    var tlsKeys = ['sni', 'peer', 'insecure', 'allowInsecure', 'allow_insecure', 'skip-cert-verify', 'alpn', 'fp', 'pinSHA256'];
    var user = decodeURIComponent(url.username), pass = decodeURIComponent(url.password);
    if (type === 'hysteria2' || type === 'anytls') {
      checkShareParams(url, tlsKeys.concat(type === 'hysteria2' ? ['obfs', 'obfs-password', 'up', 'down'] : []));
      p.password = user + (url.password ? ':' + pass : '');
      if (!p.password) throw new Error('节点链接缺少密码');
      p.udp = true;
      readShareTLS(p, get);
      if (type === 'hysteria2') {
        if (hopping) p.ports = hopping;
        if (get('obfs')) {
          if (get('obfs') !== 'salamander') throw new Error('当前仅支持 salamander 混淆');
          if (!get('obfs-password')) throw new Error('混淆缺少密码');
          p.obfs = get('obfs'); p['obfs-password'] = get('obfs-password');
        } else if (get('obfs-password')) throw new Error('混淆缺少类型');
        ['up', 'down'].forEach(function (key) {
          if (get(key)) { if (!/^[0-9]+(?:\.[0-9]+)?(?:\s*[KMG]?[bB]ps)?$/.test(get(key))) throw new Error('带宽参数无效'); p[key] = get(key); }
        });
      }
    } else if (type === 'tuic') {
      checkShareParams(url, tlsKeys.concat(['congestion_control', 'congestion-controller', 'udp_relay_mode', 'udp-relay-mode', 'disable_sni', 'disable-sni', 'reduce_rtt', 'reduce-rtt']));
      if (!user) throw new Error('TUIC 缺少认证信息');
      if (url.password) { if (!validUuid(user)) throw new Error('TUIC UUID 格式不对'); p.uuid = user; p.password = pass; }
      else p.token = user; // TUIC v4
      p.udp = true; readShareTLS(p, get);
      var cc = get('congestion_control') || get('congestion-controller');
      if (cc) { if (!['bbr', 'cubic', 'new_reno'].includes(cc)) throw new Error('TUIC 拥塞控制参数无效'); p['congestion-controller'] = cc; }
      var mode = get('udp_relay_mode') || get('udp-relay-mode');
      if (mode) { if (!['native', 'quic'].includes(mode)) throw new Error('TUIC UDP 模式无效'); p['udp-relay-mode'] = mode; }
      ['disable-sni', 'reduce-rtt'].forEach(function (key) {
        var v = get(key) || get(key.replace('-', '_'));
        if (v) { if (!/^(0|1|true|false)$/i.test(v)) throw new Error('TUIC 开关参数无效'); p[key] = /^(1|true)$/i.test(v); }
      });
    } else if (type === 'hysteria') {
      checkShareParams(url, tlsKeys.concat(['auth', 'obfs', 'protocol', 'up', 'down', 'upmbps', 'downmbps']));
      if (user || pass) throw new Error('Hysteria 1 认证请放在 auth 参数');
      if (get('auth')) p['auth-str'] = get('auth');
      p.protocol = get('protocol') || 'udp';
      if (!['udp', 'wechat-video', 'faketcp'].includes(p.protocol)) throw new Error('Hysteria 传输协议无效');
      p.up = get('up') || get('upmbps'); p.down = get('down') || get('downmbps');
      if (!p.up || !p.down) throw new Error('Hysteria 1 缺少 up/down 带宽参数');
      if (![p.up, p.down].every(function (v) { return /^[0-9]+(?:\.[0-9]+)?(?:\s*[KMG]?[bB]ps)?$/.test(v) && parseFloat(v) > 0; })) throw new Error('Hysteria 带宽参数无效');
      if (get('obfs')) p.obfs = get('obfs');
      readShareTLS(p, get);
    } else {
      checkShareParams(url, tlsKeys.concat(['tls', 'udp']));
      if (user && !url.password && type === 'socks5' && !user.includes(':')) {
        // Shadowrocket SOCKS credentials may use URL-safe Base64(user:password).
        try { var decoded = decodeBase64(user), colon = decoded.indexOf(':'); if (colon >= 0) { user = decoded.slice(0, colon); pass = decoded.slice(colon + 1); } } catch (_) {}
      }
      if (user) p.username = user;
      if (pass) p.password = pass;
      var tls = get('tls');
      if (tls && !/^(0|1|true|false)$/i.test(tls)) throw new Error('TLS 参数无效');
      if (scheme === 'https-proxy' || /^(1|true)$/i.test(tls)) { p.tls = true; readShareTLS(p, get); }
      else if (tlsKeys.some(function (key) { return get(key); })) throw new Error('TLS 参数需要开启 tls=1');
      if (type === 'socks5') {
        if (get('udp') && !/^(0|1|true|false)$/i.test(get('udp'))) throw new Error('UDP 参数无效');
        p.udp = !/^(0|false)$/i.test(get('udp'));
      } else if (get('udp')) throw new Error('HTTP 代理不支持 UDP');
    }
    return p;
  }
  function parseSSR(link) {
    var raw = decodeBase64(link.slice(6)), split = raw.indexOf('/?');
    var body = split < 0 ? raw : raw.slice(0, split);
    var m = body.match(/^(.*):(\d+):([^:]+):([^:]+):([^:]+):([^:]*)$/);
    if (!m) throw new Error('SSR 链接格式不对');
    var query = new URLSearchParams(split < 0 ? '' : raw.slice(split + 2));
    query.forEach(function (_, key) { if (!['remarks', 'group', 'obfsparam', 'protoparam', 'udpport', 'uot'].includes(key)) throw new Error('暂不支持 SSR 参数：' + key); });
    if ((query.get('udpport') && query.get('udpport') !== '0') || (query.get('uot') && query.get('uot') !== '0')) throw new Error('暂不支持 SSR 独立 UDP 端口或 UDP over TCP');
    if (!['origin', 'auth_sha1_v4', 'auth_aes128_md5', 'auth_aes128_sha1', 'auth_chain_a', 'auth_chain_b'].includes(m[3])) throw new Error('暂不支持这种 SSR 认证协议');
    if (!['plain', 'http_simple', 'http_post', 'random_head', 'tls1.2_ticket_auth', 'tls1.2_ticket_fastauth'].includes(m[5])) throw new Error('暂不支持这种 SSR 混淆');
    var server = parseServer(m[1]), port = parsePort(m[2]);
    var p = { name: shareName(query.get('remarks') ? decodeBase64(query.get('remarks')) : '', server, port),
      type: 'ssr', server: server, port: port, protocol: m[3], cipher: m[4], obfs: m[5], password: decodeBase64(m[6]), udp: true };
    if (!SS_CIPHERS.has(p.cipher) || !p.password) throw new Error('SSR 加密方式或密码无效');
    if (query.get('obfsparam')) p['obfs-param'] = decodeBase64(query.get('obfsparam'));
    if (query.get('protoparam')) p['protocol-param'] = decodeBase64(query.get('protoparam'));
    return p;
  }

  function isSubscriptionNodeExcluded(sub, name) {
    return Array.isArray(sub.excludedNodes) && sub.excludedNodes.indexOf(name)>=0;
  }
  function excludeSubscriptionNode(sub, name) {
    if(typeof name!=='string' || !name)throw new Error('节点名称无效');
    if(!Array.isArray(sub.excludedNodes))sub.excludedNodes=[];
    if(!isSubscriptionNodeExcluded(sub,name))sub.excludedNodes.push(name);
  }
  function excludedNodePattern(sub) {
    var names=Array.isArray(sub.excludedNodes)?sub.excludedNodes.filter(function(n){return typeof n==='string' && n;}):[];
    if(!names.length)return '';
    return '^(?:'+names.map(function(n){return n.replace(/[.*+?^${}()|[\]\\]/g,'\\$&').replace(/`/g,'\\x60');}).join('|')+')$';
  }

  /* ---------- 订阅（机场）：交给内核的 proxy-provider 下载、解析、定时更新 ---------- */
  var SUB_HOURS = [0, 1, 6, 12, 24, 72, 168]; // 0 = 关闭自动更新
  function makeSub(name, url, hours) {
    name = String(name || '').trim().slice(0, 30);
    url = String(url || '').trim();
    hours = Number(hours);
    if (!name) throw new Error('请填订阅名称');
    if (!/^https?:\/\/[^\s"'<>\\]+$/i.test(url)) throw new Error('订阅链接要以 http:// 或 https:// 开头');
    if (SUB_HOURS.indexOf(hours) < 0) throw new Error('更新频率不对');
    var id = 's' + Math.random().toString(36).slice(2, 8);
    return { id: id, name: name, url: url, hours: hours };
  }

  // One entry point: HTTP(S) -> subscription; share URI -> local node.
  // Parsing is local and performs no request. It never changes the current route.
  function importLinks(state, text, options) {
    options = options || {};
    var result = { nodes: [], subs: [], errors: [], skipped: 0 };
    var used = { nodes: (state.nodes || []).slice(), subs: (state.subs || []).slice(), exits: state.exits || [] };
    function canonical(value) {
      if (Array.isArray(value)) return value.map(canonical);
      if (value && typeof value === 'object') { var out = {}; Object.keys(value).sort().forEach(function (k) { if (k !== 'name') out[k] = canonical(value[k]); }); return out; }
      return value;
    }
    function fingerprint(node) { return JSON.stringify(canonical(node)); }
    var seenNodes = new Set(used.nodes.map(fingerprint));
    function subIdentity(value) { var u = new URL(value); u.hash = ''; return u.href; }
    var seenSubs = new Set(used.subs.map(function (s) { try { return subIdentity(s.url); } catch(e) { return s.url; } }));
    var lines = String(text || '').split(/\r?\n/).map(function (line, i) { return { text: line.trim(), line: i + 1 }; }).filter(function (row) { return row.text; });
    if (lines.length > 200) throw new Error('一次最多导入 200 条链接，请分批添加');
    if (!lines.length) throw new Error('请先粘贴节点链接或订阅链接');
    lines.forEach(function (row) {
      try {
        if (/^https?:\/\//i.test(row.text)) {
          var url = shareUrl(row.text);
          if (!url.hostname || /[\s"'<>\\]/.test(row.text)) throw new Error('订阅链接格式不对');
          var identity = subIdentity(row.text);
          if (seenSubs.has(identity)) { result.skipped++; return; }
          var label = '';
          try { label = decodeURIComponent(url.hash.slice(1)); } catch(e) {}
          label = String(options.name || '').trim() || label || url.hostname;
          label=label.slice(0,30);
          var base = label, n = 2;
          while (used.subs.some(function (s) { return s.name === label; })) {var suffix=' '+n++;label=base.slice(0,30-suffix.length)+suffix;}
          var sub = makeSub(label, identity, options.hours === undefined ? 24 : options.hours);
          while (used.subs.some(function(s) { return s.id === sub.id; })) sub.id = 's' + Math.random().toString(36).slice(2, 10);
          used.subs.push(sub); seenSubs.add(identity); result.subs.push(sub);
        } else {
          var node = parseNodeLink(row.text), fp = fingerprint(node);
          if (seenNodes.has(fp)) { result.skipped++; return; }
          node.name = uniqueName(used, node.name); used.nodes.push(node); seenNodes.add(fp); result.nodes.push(node);
        }
      } catch (e) { result.errors.push({ line: row.line, input: row.text, message: e.message }); }
    });
    return result;
  }

  var BLOCKED_EXIT = 'PANEL-BLOCKED-EXIT';
  function exitReferences(state, name) {
    return { defaultExit: state.exit === name, nodes: Object.keys(state.nodeExits || {}).filter(function(k){return state.nodeExits[k]===name;}).length,
      subscriptions:(state.subs||[]).filter(function(s){return s.exit===name;}).length,
      rules:(state.rules||[]).filter(function(r){return r.exit && r.exit.mode==='fixed' && r.exit.name===name;}).length };
  }
  function removeExit(state, name, resolution) {
    resolution=resolution || {mode:'block'};
    var index=(state.exits||[]).findIndex(function(e){return e.name===name;});
    if(index<0)throw new Error('这个家宽已被删除，请刷新后核对');
    if(['block','off','replace'].indexOf(resolution.mode)<0)throw new Error('请选择相关线路的处理方式');
    if(resolution.mode==='replace' && !(state.exits||[]).some(function(e){return e.name===resolution.name && e.name!==name;}))throw new Error('替代家宽不存在，请重新选择');
    var refs=exitReferences(state,name),target=resolution.mode==='replace'?resolution.name:resolution.mode==='off'?'':BLOCKED_EXIT;
    if(state.exit===name)state.exit=target;
    Object.keys(state.nodeExits||{}).forEach(function(k){if(state.nodeExits[k]===name){if(target)state.nodeExits[k]=target;else delete state.nodeExits[k];}});
    (state.subs||[]).forEach(function(s){if(s.exit===name){if(target)s.exit=target;else delete s.exit;}});
    (state.rules||[]).forEach(function(r){if(r.exit && r.exit.mode==='fixed' && r.exit.name===name)r.exit=target?{mode:'fixed',name:target}:{mode:'off'};});
    state.exits.splice(index,1);return refs;
  }

  /* ---------- 出口代理（链式）：流量先走当前线路，再经过这个代理出去 ---------- */
  function makeExit(f) {
    var name = String(f.name || '').trim().slice(0, 30);
    var server = stripBrackets(String(f.server || '').trim().toLowerCase());
    var port = parseInt(f.port, 10);
    var kind = f.kind; // http | https | socks5
    if (!name) throw new Error('请填名称');
    if (['http', 'https', 'socks5'].indexOf(kind) < 0) throw new Error('类型只能是 HTTP、HTTPS 或 SOCKS5');
    if (!server) throw new Error('请填代理地址');
    if (!(isIPv4(server) || isIPv6(server) || /^([a-z0-9-]+\.)+[a-z0-9-]{2,}$/.test(server))) throw new Error('代理地址只能是 IP 或域名');
    if (!(port >= 1 && port <= 65535)) throw new Error('端口要在 1–65535 之间');
    var p = { name: name, type: kind === 'socks5' ? 'socks5' : 'http', server: server, port: port };
    if (f.username) p.username = String(f.username);
    if (f.password) p.password = String(f.password);
    if (kind === 'https') p.tls = true;
    if (kind === 'socks5') p.udp = true;
    return p;
  }

  /* ---------- 按设备选出口：target = DIRECT | AUTO（只走线路）| 某个出口代理的名字 ---------- */
  function makeDevice(ip, name, target, source) {
    ip = String(ip || '').trim();
    var m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(ip);
    if (!m || [m[1], m[2], m[3], m[4]].some(function (x) { return +x > 255; })) throw new Error('设备 IP 格式不对');
    if (!target) throw new Error('请选择走向');
    var device = { ip: ip, name: String(name || '').slice(0, 40), target: target };
    if (source) device.source = source;
    return device;
  }

  /* ---------- 规则 ---------- */
  function makeRule(kind, value, action) {
    var v = String(value || '').trim().toLowerCase();
    if (action !== 'PROXY' && action !== 'DIRECT') throw new Error('走向只能是代理或直连');
    if (kind === 'domain' || kind === 'exact') {
      v = v.replace(/^[a-z][a-z0-9+.-]*:\/\//, '').replace(/[\/?#].*$/, '').replace(/:\d+$/, '').replace(/^\*?\./, '');
      try { v = new URL('http://' + v).hostname; } catch (e) { throw new Error('域名格式不对'); }
      if (!/^([a-z0-9-]+\.)+[a-z0-9-]{2,}$/.test(v)) throw new Error('域名格式不对，例如 example.com');
    } else if (kind === 'keyword') {
      if (!/^[a-z0-9._-]+$/.test(v)) throw new Error('关键词只能含字母数字和 . _ -');
    } else if (kind === 'ip') {
      if (v.indexOf('/') < 0) v += '/32';
      var m = /^((\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3}))\/(\d{1,2})$/.exec(v);
      if (!m || [m[2], m[3], m[4], m[5]].some(function (x) { return +x > 255; }) || +m[6] > 32) throw new Error('IP 段格式不对，例如 1.2.3.0/24');
    } else {
      throw new Error('未知规则类型');
    }
    return { kind: kind, value: v, action: action };
  }

  function ruleCondition(r) {
    var t = r.kind === 'exact' ? 'DOMAIN' : r.kind === 'domain' ? 'DOMAIN-SUFFIX' : r.kind === 'keyword' ? 'DOMAIN-KEYWORD' : 'IP-CIDR';
    return t + ',' + r.value;
  }

  function ruleLine(r) {
    return ruleCondition(r) + ',' + r.action + (r.kind === 'ip' ? ',no-resolve' : '');
  }

  function hostOf(url) { try { return new URL(url).hostname; } catch (e) { return ''; } }

  /* 某个手动节点在默认线路组里的成员名：接了出口就是「出口@节点」，否则就是节点名 */
  function memberName(state, nodeName) {
    var bindings = state.nodeExits || {};
    var e = Object.prototype.hasOwnProperty.call(bindings, nodeName) ? bindings[nodeName] : '';
    if (!e) return nodeName;
    return (state.exits || []).some(function (x) { return x.name === e; }) ? e + '@' + nodeName : 'REJECT';
  }

  function parseFinalExit(value) {
    if (!value) throw new Error('请选择最终出口：具体家宽或不使用家宽');
    var choice;
    try { choice = JSON.parse(value); } catch (e) { throw new Error('最终出口格式不正确，请重新选择'); }
    if (!Array.isArray(choice)) throw new Error('请重新选择最终出口');
    if (choice[0] === 'off') return { mode: 'off' };
    if (choice[0] === 'fixed' && typeof choice[1] === 'string' && choice[1]) return { mode: 'fixed', name: choice[1] };
    throw new Error('请重新选择最终出口');
  }

  function defaultExitTarget(state) {
    if (!state.exit) return 'AUTO';
    return (state.exits || []).some(function (e) { return e.name === state.exit; }) ? state.exit : 'REJECT';
  }

  function chainChecks(state) {
    var nodes = state.nodes || [], subs = state.subs || [], exits = state.exits || [];
    var bindings = state.nodeExits || {};
    var checks = [];
    function add(source, name, label, unit, front, exitName) {
      var exit = exits.find(function (e) { return e.name === exitName && !e.tls && /^(http|socks5)$/.test(e.type); });
      if (!exit) return;
      var member = exit.name + '@' + unit;
      var alternate = CHECK_PREFIX + member;
      if (nodes.concat(exits).some(function (p) { return p.name === alternate; })) return;
      checks.push({
        source: source, name: name, label: label, front: front, exit: exit,
        member: member, alternate: alternate, alternateType: exit.type === 'http' ? 'socks5' : 'http'
      });
    }
    nodes.forEach(function (n) {
      if (Object.prototype.hasOwnProperty.call(bindings, n.name)) add('node', n.name, n.name, n.name, n.name, bindings[n.name]);
    });
    subs.forEach(function (s) { add('subscription', s.id, s.name, 's:' + s.id, 'SUBG-' + s.id, s.exit); });
    return checks;
  }

  /*
   * 生成完整 mihomo 配置（JSON 是合法 YAML，每个对象直接写成一行）。
   *
   *   AUTO      默认线路：成员是各手动节点（接了出口的写成「出口@节点」）和各订阅（接了出口的写成「出口@订阅」）
   *   SUBG-<id> 订阅内部分组：订阅里所有节点自动选最快，给出口做前置用（有出口时才生成）
   *   <出口名>  出口分组：成员是「出口@每个前置节点/订阅」，测速测整条链；设备页和默认出口选择指向它
   *   PROXY     默认出口选择：AUTO 或某个出口；规则都指向它
   * 「出口@前置」是出口代理的一份拷贝，dialer-proxy 指向那个前置（节点，或订阅分组）。
   */
  function genYaml(state) {
    var nodes = state.nodes || [], subs = state.subs || [], exits = state.exits || [], rules = state.rules || [];
    // 用户规则始终优先，兼容历史保存顺序并保留各层内部顺序。
    rules = rules.filter(function (r) { return !r.preset; }).concat(rules.filter(function (r) { return !!r.preset; }));
    var nodeExit = state.nodeExits || {};
    var mode = ['fallback', 'url-test', 'select'].indexOf(state.mode) >= 0 ? state.mode : 'fallback';
    var testMin = Math.max(1, Math.min(120, parseInt(state.testMinutes, 10) || 10));
    var autoTest = state.autoTest !== false;
    var out = ['# 由 OpenClash 面板自动生成，请勿手改', 'mode: rule', 'log-level: info'];

    var exitMap = Object.create(null); exits.forEach(function (e) { exitMap[e.name] = e; });
    var validExit = function (n) { return n && exitMap[n] ? n : ''; };
    var ids = subs.map(function (s) { return s.id; });
    var devs = (state.deviceRouting === false ? [] : state.devices || []).filter(function (d) { return isIPv4(d.ip || '') && d.target; });
    var proxyDevs = devs.filter(function (d) { return d.source || d.target !== 'DIRECT'; });

    // 前置单元：每个手动节点；每个订阅（用它的内部分组 SUBG-<id> 当前置）
    var units = nodes.map(function (n) { return { label: n.name, dialer: n.name }; })
      .concat(subs.map(function (s) { return { label: 's:' + s.id, dialer: 'SUBG-' + s.id }; }));
    var copies = []; // 出口代理的拷贝
    exits.forEach(function (e) {
      units.forEach(function (u) {
        var c = {}; Object.keys(e).forEach(function (k) { if (k !== 'via') c[k] = e[k]; });
        c.name = e.name + '@' + u.label; c['dialer-proxy'] = u.dialer;
        copies.push(c);
      });
    });

    var pinned = new Map(), pinnedGroups = [];
    var reserved = new Set(RESERVED.concat(nodes.concat(exits, copies).map(function (p) { return p.name; })));
    var nameCounters = Object.create(null);
    function pinName(prefix) {
      prefix = prefix || 'DEVICE-NODE-';
      var count = nameCounters[prefix] || 0;
      var name;
      do { name = prefix + (++count); } while (reserved.has(name));
      nameCounters[prefix] = count;
      reserved.add(name);
      return name;
    }
    function pinSubscription(name, subId, nodeName) {
      var escaped = nodeName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      var sub=subs.find(function(s){return s.id===subId;}),g={ name: name, type: 'select', use: [subId], filter: '^' + escaped + '$', 'empty-fallback': 'REJECT' };
      if(sub && excludedNodePattern(sub))g['exclude-filter']=excludedNodePattern(sub);
      pinnedGroups.push(g);
    }
    proxyDevs.forEach(function (d) {
      if (!d.source) return;
      var key = JSON.stringify([d.source, d.target]);
      if (pinned.has(key)) return;
      var target = 'REJECT';
      if (d.source === 'node' && nodes.some(function (n) { return n.name === d.target; })) {
        target = pinName();
        pinnedGroups.push({ name: target, type: 'select', proxies: [memberName(state, d.target)] });
      } else if (d.source.indexOf('subscription:') === 0) {
        var sub = subs.find(function (s) { return s.id === d.source.slice(13); });
        if (sub && (!sub.exit || validExit(sub.exit))) {
          target = pinName();
          pinSubscription(target, sub.id, d.target);
          if (validExit(sub.exit)) {
            var chain = Object.assign({}, exitMap[sub.exit], { name: pinName(), 'dialer-proxy': target });
            delete chain.via;
            copies.push(chain);
            target = chain.name;
          }
        }
      }
      pinned.set(key, target);
    });

    var ruleTargets = new Map(), noExitGroup;
    function ruleTarget(r) {
      var node = r.node, exit = r.exit;
      var prefix = 'RULE-ROUTE-';
      if (exit && exit.mode === 'fixed' && !validExit(exit.name)) return 'REJECT';
      if (!node && exit && exit.mode === 'off') {
        if (!noExitGroup) noExitGroup = { name: pinName(prefix), 'empty-fallback': 'REJECT' };
        return noExitGroup.name;
      }
      var target = 'REJECT';
      if (!node) {
        if (!exit || exit.mode !== 'fixed') return target;
        target = exit.name;
      } else if (node.source === 'node' && nodes.some(function (n) { return n.name === node.name; })) {
        if (!exit) target = memberName(state, node.name);
        else if (exit.mode === 'off') target = node.name;
        else if (exit.mode === 'fixed') target = exit.name + '@' + node.name;
      } else if (typeof node.source === 'string' && node.source.indexOf('subscription:') === 0 && typeof node.name === 'string' && node.name) {
        var sub = subs.find(function (s) { return s.id === node.source.slice(13); });
        var home = !exit ? sub && sub.exit : exit.mode === 'fixed' ? exit.name : '';
        if (!sub || (home && !validExit(home)) || (exit && ['fixed', 'off'].indexOf(exit.mode) < 0)) return target;
        target = pinName(prefix);
        pinSubscription(target, sub.id, node.name);
        if (home) {
          var chain = Object.assign({}, exitMap[home], { name: pinName(prefix), 'dialer-proxy': target });
          delete chain.via;
          copies.push(chain);
          target = chain.name;
        }
        return target;
      }
      if (target === 'REJECT') return target;
      var name = pinName(prefix);
      pinnedGroups.push({ name: name, type: 'select', proxies: [target] });
      return name;
    }
    rules.forEach(function (r) {
      if (r.action !== 'PROXY' || (!r.node && !r.exit)) return;
      var key = JSON.stringify([r.node || null, r.exit || null]);
      if (!ruleTargets.has(key)) ruleTargets.set(key, ruleTarget(r));
    });

    // 只给已绑定的线路增加备用协议探测项，不加入测速组或转发规则。
    var diagnostics = chainChecks(state).map(function (check) {
      var probe = Object.assign({}, check.exit, { name: check.alternate, type: check.alternateType, 'dialer-proxy': check.front });
      delete probe.via;
      delete probe.tls;
      delete probe.udp;
      return probe;
    });
    var proxyObjs = nodes.concat(copies, diagnostics);
    out.push(proxyObjs.length ? 'proxies:' : 'proxies: []');
    proxyObjs.forEach(function (n) { out.push('- ' + JSON.stringify(n)); });

    if (subs.length) {
      out.push('proxy-providers:');
      subs.forEach(function (s) {
        var prov = {
          type: 'http', url: s.url, path: './proxy_provider/panel_' + s.id + '.yaml',
          interval: (SUB_HOURS.indexOf(s.hours) >= 0 ? s.hours : 24) * 3600,
          header: { 'User-Agent': ['clash.meta'] },
          'health-check': { enable: false }
        };
        out.push('  ' + JSON.stringify(s.id) + ': ' + JSON.stringify(prov));
      });
    }

    // 测速参数：开测速=定时选最快；关测速=只在当前节点断线时才换（阈值极大）；节点多时放慢，小路由器扛不住
    function tune(g, type, many) {
      g.type = type; g.url = HEALTH_URL; g.lazy = true;
      g['expected-status'] = '204';
      g['max-failed-times'] = 2;
      g.interval = type === 'url-test' ? (autoTest ? testMin * 60 : (many ? 300 : 120)) : (many ? 180 : 30);
      // 容差：新线路要比当前线路快这么多才切换。用户网络延迟高（1.5–4.5 秒），250 ms 太迟钝；测速间隔本身限制了切换频率（如 30 分钟一次），取 100 ms。
      if (type === 'url-test') g.tolerance = autoTest ? SWITCH_TOLERANCE_MS : 100000;
    }
    var helperType = mode === 'fallback' ? 'fallback' : 'url-test';

    // AUTO 的成员
    var members = nodes.map(function (n) { return memberName(state, n.name); });
    var useIds = [];
    subs.forEach(function (s) {
      var ve = validExit(s.exit);
      if (ve) members.push(ve + '@s:' + s.id);
      else if (s.exit) members.push('REJECT');
      else if(excludedNodePattern(s))members.push('SUBG-'+s.id);
      else useIds.push(s.id);
    });
    var auto = { name: 'AUTO', 'empty-fallback': 'REJECT' };
    if (!members.length && !useIds.length) {
      auto.type = 'select'; auto.proxies = ['REJECT'];
    } else {
      if (mode === 'select' && state.fixed) {
        var fm = memberName(state, state.fixed), i = members.indexOf(fm);
        if (i > 0) { members.splice(i, 1); members.unshift(fm); }
      }
      auto.type = mode;
      if (members.length) auto.proxies = members;
      if (useIds.length) auto.use = useIds;
      if (mode !== 'select') {
        tune(auto, mode, ids.length > 0 || members.length > 8);
        if (!useIds.length && members.length <= 8) auto.lazy = false;
      }
    }

    if (noExitGroup) {
      var rawNodes = nodes.map(function (n) { return n.name; });
      if (mode === 'select' && rawNodes.indexOf(state.fixed) > 0) {
        rawNodes.splice(rawNodes.indexOf(state.fixed), 1);
        rawNodes.unshift(state.fixed);
      }
      noExitGroup.type = mode;
      var unfilteredIds=[];
      subs.forEach(function(s){if(excludedNodePattern(s))rawNodes.push('SUBG-'+s.id);else unfilteredIds.push(s.id);});
      if (rawNodes.length) noExitGroup.proxies = rawNodes;
      if (unfilteredIds.length) noExitGroup.use = unfilteredIds;
      if (!rawNodes.length && !ids.length) {
        noExitGroup.type = 'select';
        noExitGroup.proxies = ['REJECT'];
      } else if (mode !== 'select') tune(noExitGroup, mode, !!ids.length || rawNodes.length > 8);
      pinnedGroups.push(noExitGroup);
    }
    var groups = [auto];
    subs.forEach(function(s){
      if(!exits.length && !excludedNodePattern(s))return;
      var g={name:'SUBG-'+s.id,use:[s.id],'empty-fallback':'REJECT'};
      if(excludedNodePattern(s))g['exclude-filter']=excludedNodePattern(s);
      tune(g,helperType,true);groups.push(g);
    });
    if (exits.length) {
      exits.forEach(function (e) { // 出口分组
        var g = { name: e.name };
        var ms = units.map(function (u) { return e.name + '@' + u.label; });
        if (!ms.length) { g.type = 'select'; g.proxies = ['REJECT']; }
        else { g.proxies = ms; tune(g, helperType, ids.length > 0 || ms.length > 8); }
        groups.push(g);
      });
    }

    var choices = ['AUTO'];
    exits.forEach(function (e) { choices.push(e.name); });
    if (state.exit && choices.indexOf(state.exit) > 0) {
      choices.splice(choices.indexOf(state.exit), 1); choices.unshift(state.exit);
    }
    groups = groups.concat(pinnedGroups);
    if (defaultExitTarget(state) === 'REJECT') choices = ['REJECT'];
    groups.push({ name: 'PROXY', type: 'select', proxies: choices });
    out.push('proxy-groups:');
    groups.forEach(function (g) { out.push('- ' + JSON.stringify(g)); });

    // 每段连续同走向规则共用一个内联集合；集合顺序保持手动优先及首次匹配语义。
    // 使用 classical 集合让 DOMAIN-KEYWORD 与后缀/精确域名一致，避免 trie 的最长后缀覆盖顺序。
    var dnsPolicy = {}, dnsProviders = {}, dnsBatches = [];
    var dnsHidden = state.dnsHidden !== false; // 旧配置保留原策略；新建/清空明确为 false。
    var aliDns = ['https://223.5.5.5/dns-query#DIRECT', 'https://doh.pub/dns-query#DIRECT'];
    function overseasDns(target) { return ['https://8.8.8.8/dns-query', 'https://1.1.1.1/dns-query'].map(function (url) { return url + '#' + encodeURIComponent(target); }); }
    (dnsHidden ? rules : []).forEach(function (r) {
      if (['domain', 'exact', 'keyword'].indexOf(r.kind) < 0) return;
      var target = r.action === 'DIRECT' ? 'DIRECT' :
        (r.node || r.exit ? ruleTargets.get(JSON.stringify([r.node || null, r.exit || null])) || 'REJECT' : 'PROXY');
      var batch = dnsBatches[dnsBatches.length - 1];
      if (!batch || batch.target !== target) { batch = { target: target, payload: [] }; dnsBatches.push(batch); }
      batch.payload.push(ruleCondition(r));
    });
    dnsBatches.forEach(function (batch, i) {
      var id = 'panel-dns-' + (i + 1);
      dnsProviders[id] = { type: 'inline', behavior: 'classical', payload: batch.payload };
      dnsPolicy['rule-set:' + id] = batch.target === 'DIRECT' ? aliDns : overseasDns(batch.target);
    });
    if (dnsHidden && state.routingMode !== 'proxy-all') dnsPolicy['geosite:cn'] = aliDns;
    var dns = {
      enable: true, ipv6: false, 'enhanced-mode': 'fake-ip', 'fake-ip-range': '198.18.0.1/16',
      listen: '0.0.0.0:7874', 'respect-rules': true, 'prefer-h3': false,
      // Bootstrap only DNS-service hostnames, never ordinary website queries.
      'default-nameserver': ['https://223.5.5.5/dns-query#DIRECT', 'udp://119.29.29.29:53#DIRECT'], 'proxy-server-nameserver': aliDns,
      nameserver: overseasDns('PROXY'), 'nameserver-policy': dnsPolicy
    };
    if (!dnsHidden) {
      var initialDns = ['udp://223.5.5.5:53#DIRECT', 'udp://119.29.29.29:53#DIRECT'];
      dns['default-nameserver'] = ['223.5.5.5', '119.29.29.29'];
      dns['proxy-server-nameserver'] = initialDns;
      dns.nameserver = initialDns;
    }
    out.push('dns: ' + JSON.stringify(dns));
    if (dnsBatches.length) out.push('rule-providers: ' + JSON.stringify(dnsProviders));

    var lines = [], seen = {};
    var exitNames = exits.map(function (e) { return e.name; });
    function deviceRule(d) { return 'SRC-IP-CIDR,' + d.ip + '/32'; }
    function deviceTarget(d) {
      if (d.source) return pinned.get(JSON.stringify([d.source, d.target])) || 'REJECT';
      return d.target === 'AUTO' || exitNames.indexOf(d.target) >= 0 ? d.target : 'REJECT';
    }
    // Mihomo 会跳过不支持 UDP 的出站。紧接着用同一条件拒绝，避免继续匹配到别的出口或直连。
    function pushProxyRule(condition, target, suffix) {
      suffix = suffix || '';
      lines.push(condition + ',' + target + suffix);
      if (target !== 'REJECT') lines.push(condition + ',REJECT' + suffix);
    }
    rules.forEach(function (r) {
      if (r.action !== 'PROXY') {
        lines.push(ruleLine(r));
        return;
      }
      var condition = ruleCondition(r);
      var suffix = r.kind === 'ip' ? ',no-resolve' : '';
      if (r.node || r.exit) {
        pushProxyRule(condition, ruleTargets.get(JSON.stringify([r.node || null, r.exit || null])), suffix);
        return;
      }
      var nested = condition + suffix;
      proxyDevs.forEach(function (d) {
        pushProxyRule('AND,((' + deviceRule(d) + '),(' + nested + '))', deviceTarget(d));
      });
      pushProxyRule(condition, 'PROXY', r.kind === 'ip' ? ',no-resolve' : '');
    });
    nodes.forEach(function (n) {
      if (seen[n.server]) return; seen[n.server] = 1;
      if (isIPv4(n.server)) lines.push('IP-CIDR,' + n.server + '/32,DIRECT,no-resolve');
      else if (isIPv6(n.server)) lines.push('IP-CIDR6,' + n.server + '/128,DIRECT,no-resolve');
      else lines.push('DOMAIN,' + n.server + ',DIRECT');
    });
    subs.forEach(function (s) { // 订阅地址本身直连，方便内核下载
      var h = hostOf(s.url);
      if (h && !seen[h]) { seen[h] = 1; lines.push((isIPv4(h) ? 'IP-CIDR,' + h + '/32,DIRECT,no-resolve' : 'DOMAIN,' + h + ',DIRECT')); }
    });
    devs.forEach(function (d) {
      if (!d.source && d.target === 'DIRECT') lines.push(deviceRule(d) + ',DIRECT');
    });
    lines.push('GEOIP,LAN,DIRECT,no-resolve');
    if (state.routingMode !== 'proxy-all') {
      lines.push('GEOSITE,cn,DIRECT');
      lines.push('GEOIP,CN,DIRECT');
    }
    proxyDevs.forEach(function (d) { pushProxyRule(deviceRule(d), deviceTarget(d)); });
    pushProxyRule('MATCH', 'PROXY');
    out.push('rules:');
    lines.forEach(function (l) { out.push('- ' + JSON.stringify(l)); });
    return out.join('\n') + '\n';
  }

  var api = {
    parseVless: parseVless, parseNodeLink: parseNodeLink, importLinks: importLinks, isSubscriptionNodeExcluded: isSubscriptionNodeExcluded, excludeSubscriptionNode: excludeSubscriptionNode, excludedNodePattern: excludedNodePattern, exitReferences: exitReferences, removeExit: removeExit, BLOCKED_EXIT: BLOCKED_EXIT, makeSub: makeSub, makeExit: makeExit, makeRule: makeRule, makeDevice: makeDevice, memberName: memberName,
    parseFinalExit: parseFinalExit, defaultExitTarget: defaultExitTarget, ruleLine: ruleLine, genYaml: genYaml, nameTaken: nameTaken, uniqueName: uniqueName, chainChecks: chainChecks, SUB_HOURS: SUB_HOURS
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PanelLib = api;
})(typeof self !== 'undefined' ? self : this);
