/* 用户提供的服务域名预设。浏览器和 Node 共用。 */
(function (root) {
  'use strict';
  var catalog = [
  {
    "id": "claude",
    "name": "Claude / Claude Code",
    "category": "ai",
    "suffix": [
      "claude.ai",
      "claude.com",
      "claude.app",
      "claudeusercontent.com",
      "claudemcpcontent.com",
      "anthropic.com",
      "clau.de",
      "claudemcpclient.com",
      "sentry.io",
      "statsigapi.net",
      "intercom.io",
      "intercomcdn.com"
    ],
    "exact": [
      "fonts.googleapis.com",
      "fonts.gstatic.com",
      "cdnjs.cloudflare.com",
      "cdn.jsdelivr.net",
      "cdn.tailwindcss.com",
      "code.jquery.com",
      "unpkg.com",
      "storage.googleapis.com",
      "registry.npmjs.org",
      "github.com",
      "raw.githubusercontent.com",
      "formulae.brew.sh",
      "http-intake.logs.us5.datadoghq.com",
      "browser-intake-us5-datadoghq.com",
      "challenges.cloudflare.com",
      "accounts.google.com",
      "oauth2.googleapis.com",
      "openidconnect.googleapis.com",
      "ssl.gstatic.com",
      "www.gstatic.com",
      "appleid.apple.com",
      "account.apple.com",
      "appleid.cdn-apple.com",
      "idmsa.apple.com",
      "gsa.apple.com",
      "humb.apple.com",
      "register.appattest.apple.com",
      "servd-anthropic-website.b-cdn.net",
      "anthropic.com.cdn.cloudflare.net",
      "anthropic.auth0.com",
      "anthropic-com.ghost.io",
      "cdn.usefathom.com"
    ],
    "keyword": [
      "datadog",
      "sift"
    ]
  },
  {
    "id": "openai",
    "name": "ChatGPT / Codex",
    "category": "ai",
    "suffix": [
      "chatgpt.com",
      "openai.com",
      "oaistatic.com",
      "oaiusercontent.com",
      "oaistatsig.com",
      "openaimerge.com",
      "ct.sendgrid.net",
      "intercom.io",
      "intercomcdn.com",
      "sentry.io",
      "statsigapi.net"
    ],
    "exact": [
      "cdn.workos.com",
      "forwarder.workos.com",
      "frontend-apps-multi-region.workos.com",
      "setup.workos.com",
      "images.workoscdn.com",
      "workos.imgix.net",
      "js.stripe.com",
      "o207216.ingest.sentry.io",
      "o33249.ingest.sentry.io",
      "rum.browser-intake-datadoghq.com",
      "challenges.cloudflare.com",
      "accounts.google.com",
      "oauth2.googleapis.com",
      "openidconnect.googleapis.com",
      "ssl.gstatic.com",
      "www.gstatic.com",
      "appleid.apple.com",
      "account.apple.com",
      "appleid.cdn-apple.com",
      "idmsa.apple.com",
      "gsa.apple.com",
      "humb.apple.com",
      "register.appattest.apple.com"
    ],
    "keyword": [
      "datadog",
      "sift"
    ]
  },
  {
    "id": "youtube",
    "name": "YouTube / Studio",
    "category": "social",
    "suffix": [
      "youtube.com",
      "youtu.be",
      "youtube-nocookie.com",
      "googlevideo.com",
      "ytimg.com",
      "ggpht.com"
    ],
    "exact": [
      "youtube.googleapis.com",
      "youtubei.googleapis.com",
      "yt3.googleusercontent.com"
    ]
  },
  {
    "id": "adsense",
    "name": "AdSense",
    "category": "social",
    "suffix": [
      "adsense.com"
    ],
    "exact": [
      "adsense.google.com",
      "pagead2.googlesyndication.com"
    ]
  },
  {
    "id": "tiktok",
    "name": "TikTok",
    "category": "social",
    "suffix": [
      "tiktok.com",
      "tiktokv.com",
      "tiktokcdn.com",
      "tiktokcdn-us.com",
      "tiktokcdn-eu.com",
      "tiktokv.us",
      "tiktokv.eu",
      "tiktokw.us",
      "tiktokw.eu",
      "ttwstatic.com",
      "ttdns2.com",
      "byteoversea.com",
      "ibyteimg.com",
      "ibytedtos.com",
      "ibytedapm.com",
      "muscdn.com",
      "musical.ly",
      "pangle-ads.com"
    ],
    "exact": []
  },
  {
    "id": "facebook",
    "name": "Facebook / Meta Business",
    "category": "social",
    "suffix": [
      "facebook.com",
      "facebook.net",
      "fbcdn.net",
      "fb.com",
      "fb.me",
      "fbsbx.com",
      "fb.watch",
      "meta.com",
      "messenger.com"
    ],
    "exact": []
  },
  {
    "id": "instagram",
    "name": "Instagram",
    "category": "social",
    "suffix": [
      "instagram.com",
      "cdninstagram.com",
      "instagr.am"
    ],
    "exact": []
  },
  {
    "id": "threads",
    "name": "Threads",
    "category": "social",
    "suffix": [
      "threads.net",
      "threads.com"
    ],
    "exact": []
  },
  {
    "id": "x",
    "name": "X / Twitter",
    "category": "social",
    "suffix": [
      "x.com",
      "twitter.com",
      "twimg.com",
      "t.co",
      "twttr.com",
      "pscp.tv",
      "periscope.tv"
    ],
    "exact": []
  },
  {
    "id": "whatsapp",
    "name": "WhatsApp",
    "category": "social",
    "suffix": [
      "whatsapp.com",
      "whatsapp.net",
      "wa.me"
    ],
    "exact": []
  },
  {
    "id": "binance",
    "name": "Binance",
    "category": "crypto",
    "suffix": [
      "binance.com",
      "binance.us",
      "binance.vision",
      "binance.me",
      "binance.info",
      "bnbstatic.com",
      "bntrace.com"
    ],
    "exact": []
  },
  {
    "id": "okx",
    "name": "OKX",
    "category": "crypto",
    "suffix": [
      "okx.com",
      "okx.cab",
      "oklink.com",
      "okxstatic.com"
    ],
    "exact": []
  },
  {
    "id": "bybit",
    "name": "Bybit",
    "category": "crypto",
    "suffix": [
      "bybit.com",
      "bytick.com",
      "bybitglobal.com"
    ],
    "exact": []
  },
  {
    "id": "bitget",
    "name": "Bitget",
    "category": "crypto",
    "suffix": [
      "bitget.com"
    ],
    "exact": []
  },
  {
    "id": "gate",
    "name": "Gate",
    "category": "crypto",
    "suffix": [
      "gate.com",
      "gate.io",
      "gateimg.com"
    ],
    "exact": []
  },
  {
    "id": "coinbase",
    "name": "Coinbase",
    "category": "crypto",
    "suffix": [
      "coinbase.com",
      "coinbasecloud.net",
      "cbhq.net"
    ],
    "exact": []
  },
  {
    "id": "kraken",
    "name": "Kraken",
    "category": "crypto",
    "suffix": [
      "kraken.com",
      "kraken.io",
      "cryptofacilities.com"
    ],
    "exact": []
  },
  {
    "id": "kucoin",
    "name": "KuCoin",
    "category": "crypto",
    "suffix": [
      "kucoin.com"
    ],
    "exact": []
  },
  {
    "id": "mexc",
    "name": "MEXC",
    "category": "crypto",
    "suffix": [
      "mexc.com"
    ],
    "exact": []
  },
  {
    "id": "htx",
    "name": "HTX",
    "category": "crypto",
    "suffix": [
      "htx.com",
      "huobi.com",
      "huobi.pro"
    ],
    "exact": []
  },
  {
    "id": "bitfinex",
    "name": "Bitfinex",
    "category": "crypto",
    "suffix": [
      "bitfinex.com"
    ],
    "exact": []
  },
  {
    "id": "gemini-exchange",
    "name": "Gemini 交易所",
    "category": "crypto",
    "suffix": [
      "gemini.com"
    ],
    "exact": []
  },
  {
    "id": "crypto-com",
    "name": "Crypto.com",
    "category": "crypto",
    "suffix": [
      "crypto.com"
    ],
    "exact": []
  },
  {
    "id": "deribit",
    "name": "Deribit",
    "category": "crypto",
    "suffix": [
      "deribit.com"
    ],
    "exact": []
  },
  {
    "id": "bitstamp",
    "name": "Bitstamp",
    "category": "crypto",
    "suffix": [
      "bitstamp.net"
    ],
    "exact": []
  },
  {
    "id": "hyperliquid",
    "name": "Hyperliquid",
    "category": "crypto",
    "suffix": [
      "hyperliquid.xyz"
    ],
    "exact": []
  },
  {
    "id": "aster",
    "name": "Aster",
    "category": "crypto",
    "suffix": [
      "asterdex.com"
    ],
    "exact": []
  },
  {
    "id": "dydx",
    "name": "dYdX",
    "category": "crypto",
    "suffix": [
      "dydx.exchange",
      "dydx.trade"
    ],
    "exact": []
  },
  {
    "id": "gmx",
    "name": "GMX",
    "category": "crypto",
    "suffix": [
      "gmx.io"
    ],
    "exact": []
  },
  {
    "id": "polymarket",
    "name": "Polymarket",
    "category": "crypto",
    "suffix": [
      "polymarket.com"
    ],
    "exact": []
  }
];
  var categories = [
    { id: 'ai', name: 'AI', hint: 'AI 预设覆盖严格，包含登录验证、公共 CDN、代码下载、监控等共享基础服务。其他应用访问这些服务时，也可能使用你为 AI 指定的出口 IP。不使用 Claude 或 GPT 时，可以保持 AI 预设关闭。' },
    { id: 'social', name: '社交运营', hint: '按账号选择稳定出口。Meta 平台可能共用域名，分开设置时请核对规则顺序。' },
    { id: 'crypto', name: '加密', hint: '使用前请确认平台的地区与账号要求，并通过 IP 检测核对实际出口位置。' }
  ];
  function remove(current, ids) {
    var kept = [];
    current.forEach(function (r) {
      if (!r.preset) { kept.push(r); return; }
      var owners = (r.presetOwners || [r.preset]).filter(function (id) { return ids.indexOf(id) < 0; });
      if (owners.length) kept.push(Object.assign({}, r, { preset: owners[0], presetOwners: owners }));
    });
    return kept;
  }
  function apply(current, ids, route, makeRule) {
    var selected = catalog.filter(function (p) { return ids.indexOf(p.id) >= 0; });
    if (!selected.length) throw new Error('请先选择服务');
    if (!route.node && (!route.exit || ['fixed', 'off'].indexOf(route.exit.mode) < 0)) throw new Error('请指定前置节点或家宽出口，再添加服务预设');
    var additions = [], known = new Map();
    var kept = remove(current, ids);
    function key(r) { return r.kind + ':' + r.value; }
    function routeKey(r) { return JSON.stringify([r.action, r.node || null, r.exit || null]); }
    kept.forEach(function (r) { known.set(key(r), r); });
    selected.forEach(function (preset) {
      ['suffix', 'exact', 'keyword'].forEach(function (type) {
        (preset[type] || []).forEach(function (value) {
          var r = makeRule(type === 'suffix' ? 'domain' : type, value, 'PROXY');
          if (route.node) r.node = Object.assign({}, route.node);
          if (route.exit) r.exit = Object.assign({}, route.exit);
          r.preset = preset.id;
          r.presetOwners = [preset.id];
          var previous = known.get(key(r));
          if (previous) {
            if (previous.preset && routeKey(previous) !== routeKey(r)) throw new Error(value + ' 已有不同走向的规则。请先编辑已有规则，统一共享域名的出口');
            if (previous.preset) {
              var owners = previous.presetOwners || [previous.preset];
              if (owners.indexOf(preset.id) < 0) previous.presetOwners = owners.concat(preset.id);
            }
            return;
          }
          known.set(key(r), r);
          additions.push(r);
        });
      });
    });
    function rank(r) {
      var p = catalog.find(function (p) { return p.id === r.preset; });
      return p ? categories.findIndex(function (c) { return c.id === p.category; }) : -1;
    }
    return kept.concat(additions).sort(function (a, b) { return rank(a) - rank(b); });
  }
  var api = { catalog: catalog, categories: categories, apply: apply, remove: remove };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PanelPresets = api;
})(typeof window !== 'undefined' ? window : this);
