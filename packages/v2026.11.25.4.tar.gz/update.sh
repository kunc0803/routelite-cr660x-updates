#!/bin/sh
# RouteLite online panel update. Only panel files change; subscriptions, nodes, Wi-Fi and the proxy
# keep running. Every update is a signed manifest (usign/Ed25519, key in the firmware) that names a
# newer version and the SHA-256 of its package; apply-update.sh installs it and rolls back on failure.
#   check            -> JSON {ok,current,latest,available,notes}
#   start [bundle]   -> start a background install (online, or from an uploaded bundle)
#   status           -> JSON {ok,state,message,version}
set -u
D=${PANEL_DIR:-/etc/clashpanel}
PUB=${UPDATE_PUB:-$D/update.pub}
SOURCES=${UPDATE_SOURCES:-$D/update-sources}
MIRRORS=${UPDATE_MIRRORS:-$D/update-mirrors}
W=${UPDATE_WORK:-/tmp/clashpanel-update}
BOARD_FILE=${UPDATE_BOARD_FILE:-/tmp/sysinfo/board_name}
APPLY_ARGS=${UPDATE_APPLY_ENV:-}
STATUS=$W/status.json
mkdir -p "$W" && chmod 700 "$W"

# No UTF-8 locale on the router: treat every argument as UTF-8 and drop broken bytes.
json() { ruby -rjson -e 'h={}; ARGV.map{|x| x.dup.force_encoding("UTF-8").scrub("")}.each_slice(2){|k,v| h[k]= v=="true" ? true : v=="false" ? false : v}; puts JSON.generate(h)' "$@"; }
fail() { json ok false error "$1"; exit 0; }
current() { tr -cd 'A-Za-z0-9.' < "$D/VERSION" 2>/dev/null; }
# vYYYY.MM.DD.N -> numbers; newer A B is true when A > B.
newer() {
  a=$(printf '%s' "$1" | tr -cd '0-9.' | tr . ' '); b=$(printf '%s' "$2" | tr -cd '0-9.' | tr . ' ')
  awk -v a="$a" -v b="$b" 'BEGIN{n=split(a,x," ");m=split(b,y," ");k=n>m?n:m;for(i=1;i<=k;i++){p=x[i]+0;q=y[i]+0;if(p>q)exit 0;if(p<q)exit 1}exit 1}'
}
fetch() { curl -fsSL --proto "=https" --connect-timeout 8 --max-time "$2" -o "$3" "$1" 2>/dev/null; }
sources() { cat "$SOURCES" "$MIRRORS" 2>/dev/null | sed 's#/*$##' | grep -E '^https://[A-Za-z0-9.-]+(:[0-9]+)?(/[A-Za-z0-9._~@%+/-]*)?$' | awk '!s[$0]++'; }
field() { jsonfilter -i "$1" -e "@.$2" 2>/dev/null; }

# A manifest is trusted only if signed by the firmware key and meant for this board.
verify_manifest() { # $1 manifest, $2 signature
  [ -s "$PUB" ] || return 2
  command -v usign >/dev/null 2>&1 || return 2
  usign -V -q -p "$PUB" -m "$1" -x "$2" 2>/dev/null || return 1
  [ "$(field "$1" board)" = "$(cat "$BOARD_FILE" 2>/dev/null)" ] || return 1
  printf '%s' "$(field "$1" version)" | grep -qE '^v[0-9]{4}\.[0-9]{2}\.[0-9]{2}\.[0-9]+$' || return 1
  printf '%s' "$(field "$1" sha256)" | grep -qE '^[0-9a-f]{64}$' || return 1
}
# Fetch the newest verified manifest from the first source that works -> $W/m.json, $BASE.
manifest() {
  BASE=; bad=0
  for base in $(sources); do
    rm -f "$W/m.json" "$W/m.json.sig"
    fetch "$base/latest.json" 20 "$W/m.json" && fetch "$base/latest.json.sig" 20 "$W/m.json.sig" || continue
    if verify_manifest "$W/m.json" "$W/m.json.sig"; then BASE=$base; return 0; fi
    bad=1
  done
  [ "$bad" = 1 ] && return 1
  return 3
}
remember_mirrors() { # extra https sources announced by a verified manifest (used next time)
  jsonfilter -i "$W/m.json" -e '@.mirrors[*]' 2>/dev/null | grep -E '^https://' | head -5 > "$MIRRORS.new" && mv "$MIRRORS.new" "$MIRRORS" 2>/dev/null
  [ -s "$MIRRORS" ] || rm -f "$MIRRORS"
}

check() {
  { command -v usign >/dev/null 2>&1 && [ -s "$PUB" ]; } || fail update_unsupported
  manifest; rc=$?
  [ "$rc" = 2 ] && fail update_unsupported
  [ "$rc" = 1 ] && fail update_bad_signature
  [ "$rc" = 0 ] || fail update_unreachable
  remember_mirrors
  latest=$(field "$W/m.json" version); cur=$(current)
  if newer "$latest" "$cur"; then avail=true; else avail=false; fi
  json ok true current "$cur" latest "$latest" available "$avail" notes "$(field "$W/m.json" notes | head -c 600)"
}

say() { json ok true state "$1" message "$2" version "${3:-}" > "$STATUS.new" && mv "$STATUS.new" "$STATUS"; }
# Install the package named by a verified manifest. $1 = manifest, $2 = package file.
install_package() {
  m=$1 pkg=$2 ver=$(field "$1" version)
  newer "$ver" "$(current)" || { say failed "已经是最新版本（$(current)），不需要升级。"; return 1; }
  [ "$(sha256sum "$pkg" | cut -d' ' -f1)" = "$(field "$m" sha256)" ] || { say failed '升级包校验失败，已停止，没有做任何修改。'; return 1; }
  stage=$W/stage; rm -rf "$stage"; mkdir -p "$stage"
  tar -tzf "$pkg" > "$W/list" 2>/dev/null || { say failed '升级包损坏，已停止，没有做任何修改。'; return 1; }
  while IFS= read -r name; do
    case "$name" in www/index.html|www/lib.js|www/presets.js|www/guide.html|api.sh|reset.sh|ipv4-only.sh|merge.rb|iot-network.sh|guest-network.sh|update.sh|update-sources|admin-password.rb|wifi24.rb|VERSION|apply-update.sh|SHA256SUMS) :;;
      *) say failed '升级包内容不对，已停止，没有做任何修改。'; return 1;;
    esac
  done < "$W/list"
  tar -xzf "$pkg" -C "$stage" || { say failed '升级包解压失败，已停止，没有做任何修改。'; return 1; }
  [ "$(tr -cd 'A-Za-z0-9.' < "$stage/VERSION")" = "$ver" ] || { say failed '升级包版本不一致，已停止，没有做任何修改。'; return 1; }
  say running "正在安装 $ver…" "$ver"
  if env $APPLY_ARGS sh "$stage/apply-update.sh" "$stage" > "$W/apply.log" 2>&1; then
    say done "已升级到 $ver。" "$ver"
  else
    say failed "升级没有成功，已自动恢复原来的版本，路由器照常使用。$(tail -1 "$W/apply.log" | head -c 120)"
    return 1
  fi
}
run_online() {
  say running '正在检查新版本…'
  manifest; rc=$?
  [ "$rc" = 0 ] || { say failed "$( [ "$rc" = 1 ] && echo '更新信息签名不对，已停止。' || echo '连不上更新服务器，请稍后再试，或用「上传升级包」。')"; return 1; }
  remember_mirrors
  ver=$(field "$W/m.json" version); rel=$(field "$W/m.json" package)
  printf '%s' "$rel" | grep -qE '^[A-Za-z0-9._/-]+\.tar\.gz$' && ! printf '%s' "$rel" | grep -q '\.\.' || { say failed '更新信息不对，已停止。'; return 1; }
  say running "正在下载 $ver…" "$ver"
  fetch "$BASE/$rel" 120 "$W/pkg.tar.gz" || { say failed '下载升级包失败，请稍后再试，没有做任何修改。'; return 1; }
  install_package "$W/m.json" "$W/pkg.tar.gz"
}
run_bundle() { # uploaded file: tar with latest.json, latest.json.sig, package.tar.gz
  say running '正在检查上传的升级包…'
  u=$W/upload; rm -rf "$u"; mkdir -p "$u"
  names=$(tar -tf "$1" 2>/dev/null | sort | tr '\n' ' ')
  [ "$names" = "latest.json latest.json.sig package.tar.gz " ] || { say failed '这不是 RouteLite 升级包，没有做任何修改。'; return 1; }
  tar -xf "$1" -C "$u" || { say failed '升级包损坏，没有做任何修改。'; return 1; }
  verify_manifest "$u/latest.json" "$u/latest.json.sig" || { say failed '升级包签名不对，没有做任何修改。'; return 1; }
  install_package "$u/latest.json" "$u/package.tar.gz"
}

case "${1:-}" in
  check) check;;
  status)
    if [ -f "$STATUS" ]; then ruby -rjson -e 'h=(JSON.parse(File.read(ARGV[0], encoding: "UTF-8")) rescue {"ok"=>true,"state"=>"idle"}); h["current"]=ARGV[1]; puts JSON.generate(h)' "$STATUS" "$(current)"
    else json ok true state idle message '' current "$(current)"; fi;;
  start)
    command -v usign >/dev/null 2>&1 && [ -s "$PUB" ] || fail update_unsupported
    if [ -f "$STATUS" ] && grep -q '"state":"running"' "$STATUS" && [ -f "$W/pid" ] && kill -0 "$(cat "$W/pid")" 2>/dev/null; then fail update_running; fi
    if [ -n "${2:-}" ]; then cp "$2" "$W/bundle.tar" || fail update_failed; mode=bundle; else mode=online; fi
    say running '正在准备升级…'
    if command -v setsid >/dev/null 2>&1; then
      setsid sh "$0" "run-$mode" </dev/null >/dev/null 2>&1 &
    else
      sh "$0" "run-$mode" </dev/null >/dev/null 2>&1 &
    fi
    echo $! > "$W/pid"
    json ok true started true;;
  run-online) run_online;;
  run-bundle) run_bundle "$W/bundle.tar"; rm -f "$W/bundle.tar";;
  *) echo "usage: $0 check|status|start [bundle]" >&2; exit 2;;
esac
exit 0
