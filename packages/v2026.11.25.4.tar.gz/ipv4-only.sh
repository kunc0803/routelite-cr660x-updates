#!/bin/sh
# 产品默认 IPv4-only；不重启 network、不更改 IPv4 地址或默认网关。
set -eu
D=${PANEL_DIR:-/etc/clashpanel}
sysdir=${PANEL_SYSCTL_DIR:-/etc/sysctl.d}
mkdir -p "$D/backup" "$sysdir"
changed=0
set_option() {
  [ "$(uci -q get "$1" || true)" = "$2" ] && return 0
  uci set "$1=$2"; changed=1
}
delete_option() {
  if uci -q get "$1" >/dev/null 2>&1; then uci -q delete "$1"; changed=1; fi
}
# 只在确有配置差异时备份和提交，避免每次应用都重复写闪存。
backup=$(mktemp -d "$D/backup/ipv4-only-XXXXXX")
for name in network dhcp openclash; do
  [ ! -f "/etc/config/$name" ] || cp -p "/etc/config/$name" "$backup/$name"
done
config_changed=0
# 已有未提交配置时拒绝覆盖，由维护者处理。
[ -z "$(uci changes network)$(uci changes dhcp)$(uci changes openclash)" ] || { echo '配置有未提交变更，IPv6设置未修改。' >&2; exit 1; }
trap 'if [ "$config_changed" = 0 ]; then uci -q revert network || true; uci -q revert dhcp || true; uci -q revert openclash || true; fi' EXIT
delete_option network.wan6
delete_option network.lan.ip6assign
delete_option network.globals.ula_prefix
set_option network.wan.ipv6 0
for key in ra dhcpv6 ndp; do set_option "dhcp.lan.$key" disabled; done
delete_option dhcp.lan.ra_slaac
delete_option dhcp.lan.ra_flags
set_option 'dhcp.@dnsmasq[0].filter_aaaa' 1
set_option openclash.config.ipv6_enable 0
set_option openclash.config.ipv6_dns 0
if [ "$changed" = 1 ]; then
  for name in network dhcp openclash; do
    [ -z "$(uci changes "$name")" ] || uci commit "$name"
  done
  config_changed=1
else
  config_changed=1
  rm -rf "$backup"
fi
policy="$sysdir/99-clashpanel-ipv4-only.conf"
tmp="$policy.new"
printf 'net.ipv6.conf.all.disable_ipv6=1\nnet.ipv6.conf.default.disable_ipv6=1\nnet.ipv6.conf.lo.disable_ipv6=1\nnet.ipv6.conf.all.forwarding=0\n' > "$tmp"
if [ -f "$policy" ] && cmp -s "$tmp" "$policy"; then rm "$tmp"; else mv "$tmp" "$policy"; fi
if [ -d /proc/sys/net/ipv6 ]; then sysctl -p "$policy" >/dev/null; fi
# 停止在 LAN 发送 IPv6 通告；只在配置改变时重载，避免周期重启。
if [ "$changed" = 1 ]; then
  [ ! -x /etc/init.d/odhcpd ] || /etc/init.d/odhcpd reload >/dev/null 2>&1
  [ ! -x /etc/init.d/dnsmasq ] || /etc/init.d/dnsmasq reload >/dev/null 2>&1
fi
