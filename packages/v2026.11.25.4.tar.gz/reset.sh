#!/bin/sh
# 清空面板的业务设置。调用方持有 api.sh 的写入锁。
set -eu
umask 077
D=${PANEL_DIR:-/etc/clashpanel}
OC=${OC_DIR:-/etc/openclash}
service=${OPENCLASH_INIT:-/etc/init.d/openclash}
backup=$(mktemp -d "$D/backup/reset-XXXXXX")
stage=$(mktemp -d "$D/.reset-XXXXXX")
old_enabled=$(uci -q get openclash.config.enable || true)
old_path=$(uci -q get openclash.config.config_path || true)
was_running=0
pidof clash >/dev/null 2>&1 && was_running=1
files="$D/state.json $D/panel.yaml $D/orig_path $D/draft-uncompiled $D/generation $D/processed.bak $OC/config/panel.yaml $OC/panel.yaml"
index=0
for file in $files; do
  index=$((index + 1))
  [ ! -f "$file" ] || cp -p "$file" "$backup/file-$index"
done
printf '%s\n' "$files" > "$backup/paths"
rollback() {
  trap - EXIT HUP INT TERM
  index=0
  for file in $files; do
    index=$((index + 1))
    if [ -f "$backup/file-$index" ]; then cp -p "$backup/file-$index" "$file"; else rm -f "$file"; fi
  done
  if [ -n "$old_path" ]; then uci set openclash.config.config_path="$old_path"; else uci -q delete openclash.config.config_path || true; fi
  if [ -n "$old_enabled" ]; then uci set openclash.config.enable="$old_enabled"; else uci -q delete openclash.config.enable || true; fi
  uci commit openclash || true
  if [ "$was_running" = 1 ]; then "$service" start 9>&- >/dev/null 2>&1 || true; fi
  rm -rf "$stage"
  printf '{"ok":false,"error":"reset_failed_settings_restored"}'
}
trap rollback EXIT
trap 'exit 1' HUP INT TERM
generation=$(cat /proc/sys/kernel/random/uuid 2>/dev/null || date +%s)
printf '%s\n' "$generation" > "$stage/generation"
printf '{"nodes":[],"subs":[],"exits":[],"nodeExits":{},"devices":[],"deviceRouting":false,"rules":[],"routingMode":"china-direct","dnsHidden":false,"mode":"url-test","autoTest":true,"testMinutes":30,"fixed":"","exit":"","_generation":"%s"}\n' "$generation" > "$stage/state.json"
cat > "$stage/panel.yaml" <<'YAML'
# 面板默认空配置
mode: rule
log-level: info
proxies: []
proxy-groups:
- name: AUTO
  type: select
  proxies: [REJECT]
- name: PROXY
  type: select
  proxies: [AUTO]
rules:
- GEOIP,LAN,DIRECT,no-resolve
- GEOSITE,cn,DIRECT
- GEOIP,CN,DIRECT
- MATCH,PROXY
- MATCH,REJECT
YAML
uci set openclash.config.enable=0
uci commit openclash
"$service" stop >/dev/null 2>&1
! pidof clash >/dev/null 2>&1
mkdir -p "$OC/config"
cp "$stage/panel.yaml" "$D/panel.yaml"
cp "$stage/panel.yaml" "$OC/config/panel.yaml"
cp "$stage/panel.yaml" "$OC/panel.yaml"
mv "$stage/state.json" "$D/state.json"
mv "$stage/generation" "$D/generation"
rm -f "$D/orig_path" "$D/draft-uncompiled" "$D/processed.bak"
rm -f "$OC"/proxy_provider/panel_*.yaml "$OC/history/panel.db"
uci set openclash.config.config_path="$OC/config/panel.yaml"
uci commit openclash
trap - EXIT HUP INT TERM
rm -rf "$stage"
printf '{"ok":true}'
