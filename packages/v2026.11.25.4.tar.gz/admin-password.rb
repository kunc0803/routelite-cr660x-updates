# One-shot root password rotation. Never log, return, or store plaintext passwords.
require 'json'
module AdminPassword
  def self.hash_value
    line=File.foreach(ENV.fetch('ADMIN_SHADOW_FILE','/etc/shadow')).find{|l|l.start_with?('root:')}
    raise 'admin_password_unavailable' unless line
    line.split(':',-1)[1]
  end
  def self.matches?(plain,hash)
    return plain.empty? if hash.empty?
    return false if hash.start_with?('!','*')
    actual=plain.crypt(hash)
    return false unless actual.bytesize==hash.bytesize
    actual.bytes.zip(hash.bytes).reduce(0){|v,(a,b)|v|(a^b)}==0
  end
  def self.change(data)
    current=data['current_password']; fresh=data['new_password']; confirm=data['confirm_password']
    raise 'admin_password_bad_input' unless current.is_a?(String) && current.valid_encoding? && !current.match?(/[\x00-\x1f\x7f]/)
    raise 'admin_password_bad_new' unless fresh.is_a?(String) && fresh.valid_encoding? && !fresh.empty? && !fresh.match?(/[\x00-\x1f\x7f]/)
    raise 'admin_password_mismatch' unless fresh==confirm
    raise 'admin_password_same' if fresh==current
    source=IO.popen(['uci','-q','get','rpcd.@login[0].password'],err:File::NULL,&:read).strip
    username=IO.popen(['uci','-q','get','rpcd.@login[0].username'],err:File::NULL,&:read).strip
    raise 'admin_password_unavailable' unless source=='$p$root' && username=='root'
    old=hash_value
    unless matches?(current,old)
      sleep 1 unless ENV['ADMIN_PASSWORD_TEST']=='1'
      raise 'admin_password_wrong_current'
    end
    exe=ENV.fetch('ADMIN_PASSWD','/bin/passwd')
    IO.popen([exe,'-a','sha512','root'],'r+',err:File::NULL) do |io|
      io.write(fresh+"\n"+fresh+"\n");io.close_write;io.read
    end
    raise 'admin_password_save_failed' unless $?.success? && matches?(fresh,hash_value)
    {'ok'=>true,'reauth_required'=>true}
  end
end
if __FILE__==$0
  begin
    puts JSON.generate(AdminPassword.change(JSON.parse(File.read(ARGV.fetch(0)))))
  rescue StandardError=>e
    known=%w[admin_password_unavailable admin_password_bad_input admin_password_bad_new admin_password_mismatch admin_password_same admin_password_wrong_current admin_password_save_failed]
    puts JSON.generate({'ok'=>false,'error'=>known.include?(e.message) ? e.message : 'admin_password_save_failed'})
  end
end
